/********************************************************************************
** Form generated from reading UI file 'Emulator.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMULATOR_H
#define UI_EMULATOR_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Emulator
{
public:
    QFrame *frame_3;
    QHBoxLayout *horizontalLayout;
    QFrame *frame;
    QGridLayout *gridLayout;
    QLabel *LED;
    QFrame *frame_2;
    QLabel *label_2;
    QFrame *frame_6;
    QVBoxLayout *verticalLayout;
    QFrame *frame_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QPushButton *pushButton;
    QFrame *frame_4;
    QHBoxLayout *horizontalLayout_2;
    QSpinBox *spinBox;
    QSlider *horizontalSlider;
    QFrame *frame_7;
    QFrame *frame_8;
    QFrame *frame_10;
    QGridLayout *gridLayout_2;
    QLabel *label_4;
    QFrame *frame_9;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_4;
    QPushButton *pushButton_7;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QWidget *Emulator)
    {
        if (Emulator->objectName().isEmpty())
            Emulator->setObjectName(QString::fromUtf8("Emulator"));
        Emulator->resize(1000, 700);
        Emulator->setMinimumSize(QSize(1000, 700));
        Emulator->setMaximumSize(QSize(1000, 700));
        frame_3 = new QFrame(Emulator);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(0, 0, 1000, 300));
        frame_3->setMinimumSize(QSize(1000, 300));
        frame_3->setMaximumSize(QSize(1000, 300));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Plain);
        horizontalLayout = new QHBoxLayout(frame_3);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        frame = new QFrame(frame_3);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(0, 276));
        frame->setMaximumSize(QSize(16777215, 276));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Plain);
        gridLayout = new QGridLayout(frame);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        LED = new QLabel(frame);
        LED->setObjectName(QString::fromUtf8("LED"));
        LED->setMinimumSize(QSize(200, 200));
        LED->setMaximumSize(QSize(200, 200));
        LED->setPixmap(QPixmap(QString::fromUtf8(":/Image/Image/led-off.png")));

        gridLayout->addWidget(LED, 0, 0, 1, 1);


        horizontalLayout->addWidget(frame);

        frame_2 = new QFrame(frame_3);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setMinimumSize(QSize(0, 276));
        frame_2->setMaximumSize(QSize(16777215, 276));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Plain);
        label_2 = new QLabel(frame_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 50, 200, 200));
        label_2->setMinimumSize(QSize(200, 200));
        label_2->setMaximumSize(QSize(200, 200));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/Icon/Image/thermometer.png")));
        frame_6 = new QFrame(frame_2);
        frame_6->setObjectName(QString::fromUtf8("frame_6"));
        frame_6->setGeometry(QRect(230, 90, 194, 130));
        frame_6->setFrameShape(QFrame::StyledPanel);
        frame_6->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame_6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        frame_5 = new QFrame(frame_6);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(frame_5);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(frame_5);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        pushButton = new QPushButton(frame_5);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Icon/Image/Refresh.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon);

        horizontalLayout_3->addWidget(pushButton);


        verticalLayout->addWidget(frame_5);

        frame_4 = new QFrame(frame_6);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        horizontalLayout_2 = new QHBoxLayout(frame_4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        spinBox = new QSpinBox(frame_4);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setMaximum(100);

        horizontalLayout_2->addWidget(spinBox);

        horizontalSlider = new QSlider(frame_4);
        horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
        horizontalSlider->setMaximum(100);
        horizontalSlider->setSingleStep(1);
        horizontalSlider->setOrientation(Qt::Horizontal);

        horizontalLayout_2->addWidget(horizontalSlider);


        verticalLayout->addWidget(frame_4);


        horizontalLayout->addWidget(frame_2);

        frame_7 = new QFrame(Emulator);
        frame_7->setObjectName(QString::fromUtf8("frame_7"));
        frame_7->setGeometry(QRect(0, 310, 1000, 330));
        frame_7->setFrameShape(QFrame::StyledPanel);
        frame_7->setFrameShadow(QFrame::Plain);
        frame_8 = new QFrame(frame_7);
        frame_8->setObjectName(QString::fromUtf8("frame_8"));
        frame_8->setGeometry(QRect(30, 30, 800, 270));
        frame_8->setMinimumSize(QSize(800, 270));
        frame_8->setMaximumSize(QSize(800, 270));
        frame_8->setFrameShape(QFrame::StyledPanel);
        frame_8->setFrameShadow(QFrame::Plain);
        frame_10 = new QFrame(frame_8);
        frame_10->setObjectName(QString::fromUtf8("frame_10"));
        frame_10->setGeometry(QRect(50, 50, 700, 170));
        frame_10->setMinimumSize(QSize(700, 170));
        frame_10->setMaximumSize(QSize(700, 170));
        frame_10->setFrameShape(QFrame::Box);
        frame_10->setFrameShadow(QFrame::Sunken);
        gridLayout_2 = new QGridLayout(frame_10);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_4 = new QLabel(frame_10);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\215\216\346\226\207\347\220\245\347\217\200"));
        font.setPointSize(72);
        label_4->setFont(font);
        label_4->setStyleSheet(QString::fromUtf8("color:rgb(255,0,0)"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_4, 0, 0, 1, 1);

        frame_9 = new QFrame(frame_7);
        frame_9->setObjectName(QString::fromUtf8("frame_9"));
        frame_9->setGeometry(QRect(840, 30, 148, 270));
        frame_9->setMinimumSize(QSize(148, 270));
        frame_9->setMaximumSize(QSize(148, 270));
        frame_9->setFrameShape(QFrame::StyledPanel);
        frame_9->setFrameShadow(QFrame::Plain);
        verticalLayout_2 = new QVBoxLayout(frame_9);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        pushButton_4 = new QPushButton(frame_9);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout_2->addWidget(pushButton_4);

        pushButton_7 = new QPushButton(frame_9);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        verticalLayout_2->addWidget(pushButton_7);

        pushButton_5 = new QPushButton(frame_9);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        verticalLayout_2->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(frame_9);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));

        verticalLayout_2->addWidget(pushButton_6);

        widget = new QWidget(Emulator);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 630, 1000, 80));
        widget->setMinimumSize(QSize(1000, 80));
        widget->setMaximumSize(QSize(1000, 80));
        horizontalLayout_4 = new QHBoxLayout(widget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        horizontalLayout_4->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        horizontalLayout_4->addWidget(pushButton_3);


        retranslateUi(Emulator);

        QMetaObject::connectSlotsByName(Emulator);
    } // setupUi

    void retranslateUi(QWidget *Emulator)
    {
        Emulator->setWindowTitle(QCoreApplication::translate("Emulator", "Form", nullptr));
        LED->setText(QString());
        label_2->setText(QString());
        label_3->setText(QCoreApplication::translate("Emulator", "\345\275\223\345\211\215\346\270\251\345\272\246\357\274\232xx\342\204\203", nullptr));
        pushButton->setText(QString());
        label_4->setText(QCoreApplication::translate("Emulator", "\350\255\246\346\210\222\345\214\272", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Emulator", "\346\250\241\346\213\237\350\255\246\346\210\222", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Emulator", "\346\250\241\346\213\237\347\273\223\346\235\237", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Emulator", "\345\274\200\350\255\246\346\212\245", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Emulator", "\345\205\263\350\255\246\346\212\245", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Emulator", "Reset", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Emulator", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Emulator: public Ui_Emulator {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMULATOR_H
