/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QFrame *frame_2;
    QHBoxLayout *horizontalLayout;
    QWidget *widget_3;
    QLabel *pic_Welcome;
    QLabel *label;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QFrame *frame_4;
    QHBoxLayout *horizontalLayout_5;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *label_5;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLabel *label_6;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLabel *label_7;
    QFrame *frame;
    QHBoxLayout *horizontalLayout_6;
    QToolButton *toolButton;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QLabel *label_8;
    QLabel *label_9;
    QFrame *frame_3;
    QGridLayout *gridLayout;
    QLabel *label_10;
    QLabel *label_11;
    QLineEdit *Commend;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QTextEdit *Feedback;
    QWidget *widget_8;
    QHBoxLayout *horizontalLayout_8;
    QFrame *frame_5;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_12;
    QWidget *widget_6;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1020, 650);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(1020, 650));
        MainWindow->setMaximumSize(QSize(1020, 650));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        frame_2 = new QFrame(centralWidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(20, 10, 981, 120));
        frame_2->setFrameShape(QFrame::StyledPanel);
        horizontalLayout = new QHBoxLayout(frame_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        widget_3 = new QWidget(frame_2);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setMinimumSize(QSize(800, 100));
        widget_3->setMaximumSize(QSize(800, 100));
        pic_Welcome = new QLabel(widget_3);
        pic_Welcome->setObjectName(QString::fromUtf8("pic_Welcome"));
        pic_Welcome->setGeometry(QRect(0, 0, 800, 100));
        pic_Welcome->setMinimumSize(QSize(800, 100));
        pic_Welcome->setMaximumSize(QSize(800, 100));
        pic_Welcome->setTextFormat(Qt::AutoText);
        pic_Welcome->setPixmap(QPixmap(QString::fromUtf8(":/Image/Image/back.jpg")));
        pic_Welcome->setScaledContents(true);
        pic_Welcome->setAlignment(Qt::AlignCenter);
        label = new QLabel(widget_3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(160, 0, 500, 100));
        label->setTextFormat(Qt::AutoText);
        label->setPixmap(QPixmap(QString::fromUtf8(":/Image/Image/title.png")));
        label->setScaledContents(true);
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(widget_3);

        widget = new QWidget(frame_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMinimumSize(QSize(150, 100));
        widget->setMaximumSize(QSize(150, 100));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setBold(true);
        font.setWeight(75);
        pushButton->setFont(font);

        verticalLayout->addWidget(pushButton);


        horizontalLayout->addWidget(widget);

        frame_4 = new QFrame(centralWidget);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setGeometry(QRect(20, 140, 750, 65));
        frame_4->setFrameShape(QFrame::StyledPanel);
        horizontalLayout_5 = new QHBoxLayout(frame_4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        widget_2 = new QWidget(frame_4);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_2 = new QHBoxLayout(widget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(55, 0));
        label_2->setMaximumSize(QSize(55, 16777215));
        label_2->setFont(font);

        horizontalLayout_2->addWidget(label_2);

        label_5 = new QLabel(widget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);

        horizontalLayout_2->addWidget(label_5);


        horizontalLayout_5->addWidget(widget_2);

        widget_4 = new QWidget(frame_4);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_3 = new QHBoxLayout(widget_4);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(widget_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(55, 0));
        label_3->setMaximumSize(QSize(55, 16777215));
        label_3->setFont(font);

        horizontalLayout_3->addWidget(label_3);

        label_6 = new QLabel(widget_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);

        horizontalLayout_3->addWidget(label_6);


        horizontalLayout_5->addWidget(widget_4);

        widget_5 = new QWidget(frame_4);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_4 = new QHBoxLayout(widget_5);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(widget_5);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(55, 0));
        label_4->setMaximumSize(QSize(55, 16777215));
        label_4->setFont(font);

        horizontalLayout_4->addWidget(label_4);

        label_7 = new QLabel(widget_5);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font);

        horizontalLayout_4->addWidget(label_7);


        horizontalLayout_5->addWidget(widget_5);

        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(20, 250, 750, 120));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Plain);
        horizontalLayout_6 = new QHBoxLayout(frame);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        toolButton = new QToolButton(frame);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setMinimumSize(QSize(100, 100));
        toolButton->setMaximumSize(QSize(100, 100));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_off.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_on.png"), QSize(), QIcon::Normal, QIcon::On);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_off.png"), QSize(), QIcon::Disabled, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_on.png"), QSize(), QIcon::Disabled, QIcon::On);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_off.png"), QSize(), QIcon::Active, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_on.png"), QSize(), QIcon::Active, QIcon::On);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_off.png"), QSize(), QIcon::Selected, QIcon::Off);
        icon.addFile(QString::fromUtf8(":/Icon/Image/led_on.png"), QSize(), QIcon::Selected, QIcon::On);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(60, 60));
        toolButton->setCheckable(true);
        toolButton->setChecked(false);

        horizontalLayout_6->addWidget(toolButton);

        pushButton_4 = new QPushButton(frame);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(100, 100));
        pushButton_4->setMaximumSize(QSize(100, 100));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Icon/Image/Speaker_off.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon1.addFile(QString::fromUtf8(":/Icon/Image/Speaker_on.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_4->setIcon(icon1);
        pushButton_4->setIconSize(QSize(60, 60));
        pushButton_4->setCheckable(true);

        horizontalLayout_6->addWidget(pushButton_4);

        pushButton_3 = new QPushButton(frame);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(100, 100));
        pushButton_3->setMaximumSize(QSize(100, 100));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Icon/Image/thermometer.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_3->setIcon(icon2);
        pushButton_3->setIconSize(QSize(60, 60));

        horizontalLayout_6->addWidget(pushButton_3);

        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 211, 80, 50));
        label_8->setMinimumSize(QSize(80, 40));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\215\216\346\226\207\344\270\255\345\256\213"));
        font1.setPointSize(14);
        label_8->setFont(font1);
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 375, 151, 50));
        label_9->setMinimumSize(QSize(80, 40));
        label_9->setFont(font1);
        frame_3 = new QFrame(centralWidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(20, 415, 750, 200));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Plain);
        gridLayout = new QGridLayout(frame_3);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_10 = new QLabel(frame_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setMaximumSize(QSize(16777215, 25));
        label_10->setFont(font);

        gridLayout->addWidget(label_10, 0, 0, 1, 1);

        label_11 = new QLabel(frame_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setMaximumSize(QSize(16777215, 25));
        label_11->setFont(font);
        label_11->setContextMenuPolicy(Qt::DefaultContextMenu);

        gridLayout->addWidget(label_11, 0, 1, 1, 1);

        Commend = new QLineEdit(frame_3);
        Commend->setObjectName(QString::fromUtf8("Commend"));
        Commend->setMaximumSize(QSize(150, 16777215));

        gridLayout->addWidget(Commend, 1, 0, 1, 1);

        pushButton_6 = new QPushButton(frame_3);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setFont(font);

        gridLayout->addWidget(pushButton_6, 2, 0, 1, 1);

        pushButton_7 = new QPushButton(frame_3);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setFont(font);

        gridLayout->addWidget(pushButton_7, 3, 0, 1, 1);

        Feedback = new QTextEdit(frame_3);
        Feedback->setObjectName(QString::fromUtf8("Feedback"));
        Feedback->setMinimumSize(QSize(0, 0));
        Feedback->setMaximumSize(QSize(16777215, 16777215));

        gridLayout->addWidget(Feedback, 1, 1, 3, 1);

        widget_8 = new QWidget(centralWidget);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        widget_8->setGeometry(QRect(30, 580, 215, 50));
        horizontalLayout_8 = new QHBoxLayout(widget_8);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        frame_5 = new QFrame(centralWidget);
        frame_5->setObjectName(QString::fromUtf8("frame_5"));
        frame_5->setGeometry(QRect(780, 140, 220, 475));
        frame_5->setMinimumSize(QSize(220, 475));
        frame_5->setFrameShape(QFrame::StyledPanel);
        frame_5->setFrameShadow(QFrame::Plain);
        verticalLayout_3 = new QVBoxLayout(frame_5);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_12 = new QLabel(frame_5);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setMinimumSize(QSize(183, 180));
        label_12->setMaximumSize(QSize(183, 180));
        label_12->setPixmap(QPixmap(QString::fromUtf8(":/Image/Image/SchoolBadge .png")));
        label_12->setScaledContents(true);

        verticalLayout_3->addWidget(label_12);

        widget_6 = new QWidget(frame_5);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        verticalLayout_2 = new QVBoxLayout(widget_6);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_13 = new QLabel(widget_6);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setFont(font);

        verticalLayout_2->addWidget(label_13);

        label_14 = new QLabel(widget_6);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setFont(font);

        verticalLayout_2->addWidget(label_14);

        label_15 = new QLabel(widget_6);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setFont(font);

        verticalLayout_2->addWidget(label_15);

        label_16 = new QLabel(widget_6);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setFont(font);

        verticalLayout_2->addWidget(label_16);

        label_17 = new QLabel(widget_6);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setFont(font);

        verticalLayout_2->addWidget(label_17);


        verticalLayout_3->addWidget(widget_6);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pic_Welcome->setText(QString());
        label->setText(QString());
        pushButton->setText(QCoreApplication::translate("MainWindow", "\347\231\273\345\275\225", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\346\234\254\346\234\272ID:", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\347\231\273\351\231\206\345\220\216\350\207\252\345\212\250\345\241\253\345\206\231", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\346\234\254\346\234\272IP:", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "\347\231\273\351\231\206\345\220\216\350\207\252\345\212\250\345\241\253\345\206\231", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\344\270\273\346\234\272IP:", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "\347\231\273\351\231\206\345\220\216\350\207\252\345\212\250\345\241\253\345\206\231", nullptr));
        toolButton->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        pushButton_4->setText(QString());
        pushButton_3->setText(QString());
        label_8->setText(QCoreApplication::translate("MainWindow", "\346\216\247\345\210\266\345\214\272", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\346\265\213\350\257\225\345\217\212\345\217\215\351\246\210\345\214\272", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "\346\211\213\345\212\250\350\276\223\345\205\245\346\214\207\344\273\244\357\274\232", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "\347\250\213\345\272\217\344\277\241\346\201\257\345\217\215\351\246\210", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "\345\217\221\351\200\201\347\273\231\346\234\254\346\234\272", nullptr));
        pushButton_7->setText(QCoreApplication::translate("MainWindow", "\345\217\221\351\200\201\347\273\231\344\270\273\346\234\272", nullptr));
        label_12->setText(QString());
        label_13->setText(QCoreApplication::translate("MainWindow", "\344\275\234\350\200\205\344\277\241\346\201\257", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "\345\255\246\345\217\267\357\274\2322115170033", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "\345\247\223\345\220\215\357\274\232\346\235\250\345\256\234\350\207\273", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "\347\217\255\347\272\247\357\274\2321703", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "\345\210\266\344\275\234\346\227\245\346\234\237\357\274\2322021-3-3", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
