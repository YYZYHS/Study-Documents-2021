/********************************************************************************
** Form generated from reading UI file 'Register.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTER_H
#define UI_REGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Register
{
public:
    QDialogButtonBox *buttonBox;
    QDialogButtonBox *buttonBox_2;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_2;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QFrame *frame_4;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *RUsrName;
    QLineEdit *RUsrPassword;
    QLineEdit *RServerIP;
    QLineEdit *ClientIP;
    QLineEdit *PortID;

    void setupUi(QDialog *Register)
    {
        if (Register->objectName().isEmpty())
            Register->setObjectName(QString::fromUtf8("Register"));
        Register->resize(320, 240);
        buttonBox = new QDialogButtonBox(Register);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(10, 270, 221, 41));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox_2 = new QDialogButtonBox(Register);
        buttonBox_2->setObjectName(QString::fromUtf8("buttonBox_2"));
        buttonBox_2->setGeometry(QRect(0, 200, 301, 32));
        buttonBox_2->setOrientation(Qt::Horizontal);
        buttonBox_2->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        widget = new QWidget(Register);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 10, 310, 180));
        horizontalLayout_2 = new QHBoxLayout(widget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        frame_3 = new QFrame(widget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        verticalLayout_3 = new QVBoxLayout(frame_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_4 = new QLabel(frame_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);

        label_5 = new QLabel(frame_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_3->addWidget(label_5);

        label_6 = new QLabel(frame_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_3->addWidget(label_6);

        label_7 = new QLabel(frame_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_3->addWidget(label_7);

        label_8 = new QLabel(frame_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_3->addWidget(label_8);


        horizontalLayout_2->addWidget(frame_3);

        frame_4 = new QFrame(widget);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setFrameShape(QFrame::StyledPanel);
        frame_4->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(frame_4);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        RUsrName = new QLineEdit(frame_4);
        RUsrName->setObjectName(QString::fromUtf8("RUsrName"));

        verticalLayout_4->addWidget(RUsrName);

        RUsrPassword = new QLineEdit(frame_4);
        RUsrPassword->setObjectName(QString::fromUtf8("RUsrPassword"));

        verticalLayout_4->addWidget(RUsrPassword);

        RServerIP = new QLineEdit(frame_4);
        RServerIP->setObjectName(QString::fromUtf8("RServerIP"));

        verticalLayout_4->addWidget(RServerIP);

        ClientIP = new QLineEdit(frame_4);
        ClientIP->setObjectName(QString::fromUtf8("ClientIP"));

        verticalLayout_4->addWidget(ClientIP);

        PortID = new QLineEdit(frame_4);
        PortID->setObjectName(QString::fromUtf8("PortID"));

        verticalLayout_4->addWidget(PortID);


        horizontalLayout_2->addWidget(frame_4);


        retranslateUi(Register);
        QObject::connect(buttonBox, SIGNAL(accepted()), Register, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Register, SLOT(reject()));

        QMetaObject::connectSlotsByName(Register);
    } // setupUi

    void retranslateUi(QDialog *Register)
    {
        Register->setWindowTitle(QCoreApplication::translate("Register", "Dialog", nullptr));
        label_4->setText(QCoreApplication::translate("Register", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
        label_5->setText(QCoreApplication::translate("Register", "\345\257\206\347\240\201\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("Register", "\346\234\215\345\212\241\345\231\250IP\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("Register", "\345\256\242\346\210\267\347\253\257IP\357\274\232", nullptr));
        label_8->setText(QCoreApplication::translate("Register", "\347\253\257\345\217\243\345\217\267\357\274\232", nullptr));
        ClientIP->setPlaceholderText(QString());
    } // retranslateUi

};

namespace Ui {
    class Register: public Ui_Register {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTER_H
