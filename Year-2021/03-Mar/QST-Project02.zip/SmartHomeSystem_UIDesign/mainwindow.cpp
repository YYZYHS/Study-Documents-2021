#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap pixmap = QPixmap(":/Image/Image/background3.jpg").scaled(this->size());
    QPalette palette(this->palette());
    palette.setBrush(QPalette::Background,QBrush(pixmap));
    this->setPalette(palette);
    connect(&login,SIGNAL(openemulator()),this,SLOT(OpenEmulator()));
    connect(&e,SIGNAL(mainwindowclose()),this,SLOT(close()));
    connect(this,SIGNAL(led_on()),&e,SLOT(LED_on()));
    connect(this,SIGNAL(led_off()),&e,SLOT(LED_off()));
    connect(&login,SIGNAL(upload()),this,SLOT(Upload()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    login.exec();
}


void MainWindow::OpenEmulator()
{
    qDebug()<<"e";
    e.show();
    qDebug()<<"e";
}

void MainWindow::on_toolButton_clicked(bool checked)
{
    if(checked == 0)
    {
        //关灯
        qDebug()<<"check == 0";
        emit led_off();
    }
    else
    {
        //开灯
        qDebug()<<"check == 1";
        emit led_on();
    }
}

void MainWindow::on_pushButton_4_clicked(bool checked)
{
    if(checked == 0)
    {
        //关闭警报
        buzzer->stop();

    }
    else
    {
        //打开警报
        buzzer->setLoops(100);
        buzzer->play();

    }
}

void MainWindow::on_pushButton_3_clicked()
{
    ui->Feedback->setText(e.GetTemperature());
}

void MainWindow::Upload()
{
    //创建socket
    //socket=IP地址+端口号
    socket = new QTcpSocket(this);
    //连接
    socket->connectToHost(m.IPAddr,m.port);
    //接收信息
    connect(socket,SIGNAL(readyRead()),this,SLOT(ReceiveMessage()));
}

void MainWindow::Receivemessage()
{
    QByteArray arr = socket->readAll();
    t.receivemessage(arr,m);

    //t.receivemessage(type,m);
}

void MainWindow::Sendmessage(MessageType type,message m)
{
    QByteArray temp=t.sendmessage(type,m);
    //socket->write(data,data.length());
    socket->write(temp);
    //socket->write(data.toUtf8().data(),strlen(data.toUtf8().data()));

}

