#include "Message.h"

MessageTypes::MessageTypes()
{

}
